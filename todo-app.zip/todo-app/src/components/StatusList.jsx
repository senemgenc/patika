import React, { useState } from 'react'

const StatusList = (props) => {
    const [editContent, setEditContent] = useState('')
    const [statusName, setStatusName] = useState('')

    const [editStates, setEditStates] = useState(props.categoryStatus.map(() => false));

    const handleEditContent = (index) => {
        if (editContent) {
            props.onStatusEditClick(index, editContent)
            setEditStates(prevStates => [...prevStates.slice(0, index), false, ...prevStates.slice(index + 1)])
        }
    }

    return (
        <div className='box'>
            <h2>Status of {props.categoryName} </h2>
            <div className='form'>
                <input value={statusName} onChange={e => setStatusName(e.target.value)} placeholder='Add new status'/>
                <button onClick={() => props.onStatusAddClick(statusName)}>Add</button>
            </div>
            <ul>

                {props.categoryStatus.map((status, index) =>
                    <li key={index}>
                        {!editStates[index] ? (
                            <p className='status'>{status}</p>
                        ) : (
                            <input value={editContent} onChange={e => setEditContent(e.target.value)} placeholder={status} />
                        )}
                        {!editStates[index] ? (
                            <button className='edit' onClick={() => setEditStates(prevStates => [...prevStates.slice(0, index), true, ...prevStates.slice(index + 1)])}>Edit</button>
                        ) : (
                            <button className='done' onClick={() => handleEditContent(index)}>Done</button>
                        )}
                        {!editStates[index] ? (
                            <button className='delete' onClick={() => props.onStatusDeleteClick(index)}>Delete</button>
                        ) : (
                            <button className='cancel' onClick={() => setEditStates(prevStates => [...prevStates.slice(0, index), false, ...prevStates.slice(index + 1)])}>Cancel</button>
                        )}
                    </li>
                )}
            </ul>
        </div>
    )
}

export default StatusList