import React, { useState } from 'react'

const CategoryList = (props) => {
    const [editContent, setEditContent] = useState('')
    const [input, setInput] = useState('')
    const [editStates, setEditStates] = useState(props.categories.map(() => false));

    const handleEditContent = (index) => {
        if (editContent) {
            props.onCategoryEditClick(index, editContent)
            setEditStates(prevStates => [...prevStates.slice(0, index), false, ...prevStates.slice(index + 1)])
        }
        else {
            alert('Category Content not be empty')
        }
    }

    return (
        <div className='box'>
            <h2>CategoryList</h2>
            <div className='form'>
                <input value={input} onChange={e => setInput(e.target.value)} placeholder='Add new category' />
                <button onClick={() => props.onCategoryAddClick(input)}>ADD</button>
            </div>
            <ul>
                {props.categories.map((category, index) =>
                    <li key={index}>
                        {!editStates[index] ? (
                            <button className='category' onClick={() => props.onCategoryChangeClick(index)}>{category.name}</button>
                        ) : (
                            <input value={editContent} onChange={e => setEditContent(e.target.value)} placeholder={category.name} />
                        )}
                        {!editStates[index] ? (
                            <button className='edit' onClick={() => setEditStates(prevStates => [...prevStates.slice(0, index), true, ...prevStates.slice(index + 1)])}>Edit</button>
                        ) : (
                            <button className='done' onClick={() => handleEditContent(index)}>Done</button>
                        )}
                        {!editStates[index] ? (
                            <button className='delete' onClick={() => props.onCategoryDeleteClick(index)}>Delete</button>
                        ) : (
                            <button className='cancel' onClick={() => setEditStates(prevStates => [...prevStates.slice(0, index), false, ...prevStates.slice(index + 1)])}>Cancel</button>
                        )}
                    </li>
                )}
            </ul>
        </div>
    );
}

export default CategoryList