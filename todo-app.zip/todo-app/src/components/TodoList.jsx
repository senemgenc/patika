import React, { useState } from 'react'

const TodoList = (props) => {


    const [editContent, setEditContent] = useState('')
    const [todoContent, setTodoContent] = useState('')
    const [todoCategory, setTodoCategory] = useState('')
    const [todoStatus, setTodoStatus] = useState('')
    const [editStates, setEditStates] = useState(props.todoList.map(() => false));
    const handleEditContent = (index) => {
        if (editContent) {
            props.onTodoEditClick(index, editContent)
            setEditStates(prevStates => [...prevStates.slice(0, index), false, ...prevStates.slice(index + 1)])
        }
        else {
            alert('Todo not be empty')
        }
    }


    return (
        <div className='box'>
            <h2>TodoList</h2>
            <div className='form'>
                <input value={todoContent} onChange={e => setTodoContent(e.target.value)} placeholder='Add new todo' />
                <select value={todoCategory} onChange={e => setTodoCategory(e.target.value)}>
                    <option value=''>Select</option>
                    {props.categories.map((category, index) =>
                        <option key={index}>{category.name}</option>
                    )}
                </select>
                <select value={todoStatus} onChange={e => setTodoStatus(e.target.value)}>
                    <option value=''>Select</option>
                    {props.categoryStatus.map((status, index) =>
                        <option key={index}>{status}</option>
                    )}
                </select>
                <button onClick={() => props.onTodoAddClick(todoContent, todoCategory, todoStatus)}>Add</button>
            </div>
            <ul>
                {props.todoList.map((todo, index) =>
                    <li key={index}>
                        <div className='todo'>
                            {!editStates[index] ? (
                                <p>{todo.name}</p>
                            ) : (
                                <input
                                    value={editContent}
                                    onChange={e => setEditContent(e.target.value)}
                                    placeholder={todo.name}
                                />
                            )}
                            <span className='category'>{todo.category}</span>
                            <span className='status'>{todo.status}</span>
                        </div>
                        {!editStates[index] ? (
                            <button className='edit' onClick={() => setEditStates(prevStates => [...prevStates.slice(0, index), true, ...prevStates.slice(index + 1)])}>Edit</button>
                        ) : (
                            <button className='done' onClick={() => handleEditContent(index)}>Done</button>
                        )}
                        {!editStates[index] ? (
                            <button className='delete' onClick={() => props.onTodoDeleteClick(index)}>Delete</button>
                        ) : (
                            <button className='cancel' onClick={() => setEditStates(prevStates => [...prevStates.slice(0, index), false, ...prevStates.slice(index + 1)])}>Cancel</button>
                        )}
                    </li>
                )}
            </ul>
        </div>

    )
}

export default TodoList