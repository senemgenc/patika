import './App.css'

import { useEffect, useState } from 'react'
import TodoList from './components/TodoList'
import CategoryList from './components/CategoryList'
import StatusList from './components/StatusList'

const ModalList = {
  TodoList: 1,
  CategoryList: 2,
  StatusList: 3
}

function App() {
  const [currentModal, setCurrentModal] = useState(ModalList.TodoList)
  const [currentCategory, setCurrentCategory] = useState(0)


  const [appData, setAppData] = useState({
    todoList: [
      {
        name: 'Todo 1',
        category: 'Kişisel',
        status: 'new',
      }
    ],
    categoryList: [
      {
        name: 'Kişisel',
        statusList: ['new', 'todo', 'progress', 'completed']
      },
      {
        name: 'Sosyal',
        statusList: ['new', 'todo', 'progress', 'waiting for qa', 'completed']
      },
      {
        name: 'Teknoloji',
        statusList: ['new', 'todo', 'progress', 'completed']
      }
    ],
  })


//Modal Control
  const changeModal = (modal) => {
    setCurrentModal(modal)
  }
//Category Control
  const handleCategoryChange = (categoryIndex) => {
    setCurrentCategory(categoryIndex)
    setCurrentModal(ModalList.StatusList)
  }

  //New category adding
  const handleAddNewCategory = (name) => {
    if (name) {
      setAppData({
        ...appData,
        categoryList: [
          ...appData.categoryList,
          {
            name,
            statusList: []
          }
        ]
      })
    }
    else {
      alert('Category not be empty')
    }
  }

  //Delete category
  const handleDeleteCategory = (categoryIndex) => {
    setAppData({
      ...appData,
      categoryList: appData.categoryList.filter((category, index) => index !== categoryIndex)
    })
  }

  //Edit category
  const handleEditCategory = (categoryIndex, value) => {
    setAppData({
      ...appData,
      categoryList: appData.categoryList.map((category, index) => {
        if (index === categoryIndex) {
          return {
            ...category,
            name: value
          }
        }
        return category
      })
    })
  }

  //New todo adding
  const handleAddNewTodo = (name, category, status) => {
    if (name && category && status) {
      setAppData({
        ...appData,
        todoList: [
          ...appData.todoList,
          {
            name,
            category,
            status
          }
        ]
      })
    }
    else {
      alert('Todo not be empty')
    }
  }

  //Delete todo
  const handleDeleteTodo = (todoIndex) => {
    setAppData({
      ...appData,
      todoList: appData.todoList.filter((todo, index) => index !== todoIndex)
    })
  }

  //Edit todo
  const handleEditTodo = (todoIndex, value) => {
    setAppData({
      ...appData,
      todoList: appData.todoList.map((todo, index) => {
        if (index === todoIndex) {
          return {
            ...todo,
            name: value
          }
        }
        return todo
      })
    })
  }

  //New status adding
  const handleAddStatus = (value) => {
    if (value) {
      setAppData({
        ...appData,
        categoryList: appData.categoryList.map((category, index) => {
          if (index === currentCategory) {
            return {
              ...category,
              statusList: [
                ...category.statusList,
                value
              ]
            }
          }
          return category
        })
      })
    }
    else {
      alert('Status not be empty')
    }
  }

  //Delete status
  const handleDeleteStatus = (statusIndex) => {
    setAppData({
      ...appData,
      categoryList: appData.categoryList.map((category, index) => {
        if (index === currentCategory) {
          return {
            ...category,
            statusList: category.statusList.filter((status, index) => index !== statusIndex)
          }
        }
        return category
      })
    })
  }

  //Edit status
  const handleStatusEdit = (statusIndex, value) => {
    setAppData({
      ...appData,
      categoryList: appData.categoryList.map((category, index) => {
        if (index === currentCategory) {
          return {
            ...category,
            statusList: category.statusList.map((status, index) => {
              if (index === statusIndex) {
                return value
              }
              return status
            })
          }
        }
        return category
      })
    })
  }

  return (
    <div className='container'>
      <div className='header'>
        <h1>ToDo App</h1>
      </div>
      <div className='navigation'>
        <button onClick={() => changeModal(ModalList.TodoList)}>Todos</button>
        <button onClick={() => changeModal(ModalList.CategoryList)}>Categories</button>
      </div>
      <div className='modals'>
        {
          currentModal === ModalList.TodoList &&
          <TodoList
            todoList={appData.todoList}
            onTodoAddClick={handleAddNewTodo}
            onTodoDeleteClick={handleDeleteTodo}
            onTodoEditClick={handleEditTodo}
            categories={appData.categoryList}
            categoryStatus={appData.categoryList[currentCategory].statusList}
          />
        }
        {
          currentModal === ModalList.CategoryList &&
          <CategoryList
            categories={appData.categoryList}
            onCategoryChangeClick={handleCategoryChange}
            onCategoryAddClick={handleAddNewCategory}
            onCategoryDeleteClick={handleDeleteCategory}
            onCategoryEditClick={handleEditCategory}
          />
        }
        {
          currentModal === ModalList.StatusList &&
          <StatusList
            categoryIndex={currentCategory}
            categoryName={appData.categoryList[currentCategory].name}
            categoryStatus={appData.categoryList[currentCategory].statusList}
            onStatusAddClick={handleAddStatus}
            onStatusDeleteClick={handleDeleteStatus}
            onStatusEditClick={handleStatusEdit}
          />
        }
      </div>
    </div>
  )
}

export default App
